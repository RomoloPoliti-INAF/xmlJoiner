# xmlJoiner

Join two or more PARC Telemetry files downloaded from ESA EDDS.

## Installation

To install the reader you can use the command:

```shell
$ python3 -m pip install xmlJoiner
```

